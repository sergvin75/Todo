const mongoose = require('mongoose');
const dotenv = require('dotenv');
const fs = require('fs');

// DEPLOY INFO
setDeployInfo();

dotenv.config({ path: './config.env' });
process.env.UV_THREADPOOL_SIZE = process.env.THREADPOOLS;
const app = require('./app');

const DB = process.env.DATABASE_LOCAL;
mongoose.Promise = global.Promise;
mongoose
    .connect(DB, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    })
    .then(
        () => {
            console.log(`connection to ${DB}`);
            console.log('DB connections successful!!!');
        },
        (error) => {
            console.log('Database error: ' + error);
        },
    );

const port = process.env.PORT || 3000;
const server = app.listen(port, () => {
    console.log(`App running on port ${port}... as ${process.env.NODE_ENV}`);
});
process.on('unhandledRejection', (err) => {
    console.log('UNHANDLED REJECTION!💥 Shutting down...');
    console.log(err.name, err.message);
    server.close(() => {
        process.exit(1);
    });
});

// function setDeployInfo(app) {
function setDeployInfo() {
    try {
        if (!fs.existsSync('./deploy_info.json')) {
            const deployInfo = {
                version: 0,
                date: 0,
                backendVersion: '0.0.0',
                clientVersion: '0.0.0',
                dateString: '',
                versioningStartedAt: new Date(),
            };

            const updatedDeployInfo = JSON.stringify(deployInfo, null, 2);
            fs.writeFileSync('./deploy_info.json', updatedDeployInfo);

            return setDeployInfo();
        }

        const deployInfo = JSON.parse(fs.readFileSync('./deploy_info.json'));
        const backendVersion = JSON.parse(fs.readFileSync('./package.json')).version;
        const clientVersion = JSON.parse(fs.readFileSync('./client/package.json')).version;
        const dateNow = Date.now();

        if (dateNow - deployInfo.date > 15000) {
            // set limit for preventing of restarting process in Nodemon environment (if nodemon.json doesn't exist)
            deployInfo.version++;
            deployInfo.date = dateNow;
            deployInfo.dateString = new Date(dateNow);
            deployInfo.backendVersion = backendVersion;
            deployInfo.clientVersion = clientVersion;

            const updatedDeployInfo = JSON.stringify(deployInfo, null, 2);
            fs.writeFileSync('./deploy_info.json', updatedDeployInfo);
        }
    } catch (errs) {
        console.log('UPDATE DEPLOY_INFO:', errs);
    }
}
