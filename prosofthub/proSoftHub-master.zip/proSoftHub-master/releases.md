#### [BE] 1.1.0 / [FE] 1.0.0 (22.01.2022)

1. Созданы основные интерфейсы и создана структура проекта.
2. Подготовлен проектный email: betmarathonuk@gmail.com пароль: vegas1vegas.
3. Разработаны API Запросы по Auntification: Registration, Login, Logout, Verify user email.
4. Разработана сущность **User** и API к нему со следующими командами: Get my personal data, Get User By ID,
   ForgotPassword, ResetPassword, Update My Password, UnSubscriber from email, Update Current User Data, Add New User (
   role "Owner"), Get users (role "owner"), Get admins (role "owner"), Get all unconfirmed users (role "owner"), Get all
   confirmed users (role "owner"), Get Current (role "owner"), Get All User Emails (role "owner"), Get All Users (role "
   owner")
5. Создано отзывчивое навигационное меню
