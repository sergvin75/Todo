import { Component, Inject, OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
    start: boolean = false;
    burgerMenu = false;

    constructor(@Inject(DOCUMENT) private document: Document) {}

    ngOnInit(): void {
        this.startOrResumeTimer();
    }

    startOrResumeTimer() {
        setInterval(() => {
            this.start = true;
        }, 100);
    }
    burgerMenuToggle() {
        this.burgerMenu = !this.burgerMenu;
        this.document.body.classList.toggle('lock');
    }
}
