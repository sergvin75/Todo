export interface ContentCard {
    logo: string;
    img: string;
    title: string;
    text: string;
    url: string;
    action?: string;
}
