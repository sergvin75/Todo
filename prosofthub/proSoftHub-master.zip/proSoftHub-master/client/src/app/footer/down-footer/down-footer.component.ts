import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-down-footer',
  templateUrl: './down-footer.component.html',
  styleUrls: ['./down-footer.component.scss']
})
export class DownFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
